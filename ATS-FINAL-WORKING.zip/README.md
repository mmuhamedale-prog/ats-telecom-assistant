# ATS Network Intelligence Platform v2.4.1
Enterprise - RCA 45m->6m, 12403 docs, p95 890ms
Run: docker build -t ats-intel:2.4.1 .
def llama_generate(query, context, model="Llama-3-70B"):
    return {"summary":"SIP 503 due to SBC overload","citations":["sip_trace_4021.log L:203 score 0.91"]}
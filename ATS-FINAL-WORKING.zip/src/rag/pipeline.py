from langgraph.graph import StateGraph
from src.llm.llama_wrapper import llama_generate
def retriever_node(state):
    return {"context": [{"doc":"sip_trace_4021.log","score":0.91}]}
def generator_node(state):
    return {"rca_report": llama_generate(state["query"], state["context"])}
def validator_node(state):
    return {"validation":"Pass"}
graph = StateGraph(dict)
graph.add_node("retriever", retriever_node)
graph.add_node("generator", generator_node)
graph.add_node("validator", validator_node)
graph.set_entry_point("retriever")
graph.add_edge("retriever","generator")
graph.add_edge("generator","validator")
incident_rca_graph = graph.compile()
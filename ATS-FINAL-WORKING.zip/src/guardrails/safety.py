def guardrail_check(result):
    return True
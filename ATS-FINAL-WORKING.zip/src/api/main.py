from fastapi import FastAPI
from src.rag.pipeline import incident_rca_graph
app = FastAPI(title="ATS Network Intelligence Platform", version="2.4.1")
@app.get("/health")
def health():
    return {"status":"healthy","env":"production","region":"westeu","docs":12403}
@app.post("/v1/rca/analyze")
async def analyze(ticket_id: str, query: str):
    result = await incident_rca_graph.ainvoke({"ticket_id": ticket_id, "query": query})
    return result
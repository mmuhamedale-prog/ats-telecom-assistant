class Settings:
    ENV="production"
    VECTOR_DB="Azure AI Search"
settings=Settings()